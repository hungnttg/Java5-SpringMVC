package com.example.lab2.model;

import java.util.ArrayList;
import java.util.List;

import com.example.lab2.entity.Product;

public class Cart {
	private final List<CartItem> items;
	private double total;

	public Cart() {
		items = new ArrayList<CartItem>();
		total = 0;

	}

	public CartItem getItem(Product p) {
		for (CartItem item : items) {
			if (item.getProduct().getId() == p.getId()) {
				return item;
			}
		}
		return null;

	}

	public List<CartItem> getItem() {
		return items;

	}
	public int getItemCount() {
		return items.size();
	}
	
	
//public void addItem(CartItem item) {
//	addItem(item.getProduct().item.getQuantity());
//}
//them moi 1 san pham
	public void addItem(Product p, int quantity) {
		CartItem item = getItem(p);
		if (item != null) {

			item.setQuantity(item.getQuantity() + 1);
		} else {
			item = new CartItem(p);// tao moi 1 san pham
			item.setQuantity(quantity);// gan so luong
			items.add(item); // them vao tap san pham 
		}
	}
//sua san pham
	public void updateItem(Product p, int quantity) {
		CartItem item= getItem(p);
		if(item!=null) {
			item.setQuantity(quantity);
		}
		
	}
	//xoa san pham
	public void removeItem(Product p) {
		CartItem item=getItem(p);
		if(item!=null) {
			items.remove(item);
		}
		
	}
	
	// xoa all sp
	public void clear() {
		items.clear();
		total=0;
	}
	// lam trong gio hang
	public boolean isEmpty() {
		return items.isEmpty();
	}
	public double getTotal() {
		total=0;
		for(CartItem item: items) {
			total+= item.getSubToTal();
		}
		return total;
	}
}
