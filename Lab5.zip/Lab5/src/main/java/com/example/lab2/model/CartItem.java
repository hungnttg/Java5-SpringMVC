package com.example.lab2.model;

import com.example.lab2.entity.Product;

public class CartItem {
	private final Product product;
	private int quantity;
	private double subToTal;

	public int getQuantity() {
		return quantity;
	}

	public CartItem(Product product, int quantity, double subToTal) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.subToTal = subToTal;
	}

	public CartItem(Product product) {
		this.product = product;
		this.quantity = 1;
		this.subToTal = product.getPrice();
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getSubToTal() {
		return subToTal;
	}

	public void setSubToTal(double subToTal) {
		this.subToTal = subToTal;
	}

	public Product getProduct() {
		return product;
	}
}
