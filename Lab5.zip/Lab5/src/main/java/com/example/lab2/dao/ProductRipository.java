package com.example.lab2.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.lab2.entity.Product;

public interface ProductRipository extends JpaRepository<Product, Long>{
	Product findBySku(String sku);

}
