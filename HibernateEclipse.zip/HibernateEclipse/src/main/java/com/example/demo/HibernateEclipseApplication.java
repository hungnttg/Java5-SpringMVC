package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateEclipseApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateEclipseApplication.class, args);
	}

}
