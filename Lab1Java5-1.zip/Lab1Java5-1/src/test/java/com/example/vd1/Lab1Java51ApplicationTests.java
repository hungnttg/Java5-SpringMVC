package com.example.vd1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1Java51ApplicationTests {

	@Test
	void contextLoads() {
	}

}
