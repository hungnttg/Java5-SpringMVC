package com.example.vd1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller//chi ra day la controller
@RequestMapping("/student/")//tham chieu den thu muc student
public class StudentController {
	
	@RequestMapping("bean")//tham chieu tiep den file bean.jsp
	public String bean(ModelMap model)//model dung de luu du lieu va truyen di
	{
		Student s = new Student("Nguyen Van An",7.5,"APP");//tao moi 1 doi tuong student
		model.addAttribute("student", s);//dua thuoc tinh student vao model
		return "student/bean";//tra ve ket qua
	}

}
