package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java5GioHangT620201Application {

	public static void main(String[] args) {
		SpringApplication.run(Java5GioHangT620201Application.class, args);
	}

}
