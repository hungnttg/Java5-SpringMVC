package com.example.vd1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2Java5Su2020Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab2Java5Su2020Application.class, args);
	}

}
