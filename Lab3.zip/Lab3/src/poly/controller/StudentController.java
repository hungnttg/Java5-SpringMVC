package poly.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import poly.bean.Student;

@Controller
@RequestMapping("/student/")
public class StudentController {
	//phuong thuc su dung cho HTML thuong
	@RequestMapping("edit")
	public String edit(ModelMap model)
	{
		Student sv = new Student("Nguyen Van Teo",9.5,"WEB");
		model.addAttribute("student", sv);
		return "student";
	}
	//phuong thuc su dung cho Spring form
	@RequestMapping("update")
	public String update(@ModelAttribute("student") Student student)
	{
		return "student";
	}

}
