package com.example.vd1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2Java5Su2020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
