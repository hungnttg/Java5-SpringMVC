package com.example.vd1.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.vd1.dao.ProductRepository;
import com.example.vd1.dao.ProductService;
import com.example.vd1.entity.Product;
import com.example.vd1.model.Cart;

import com.example.vd1.model.CartManager;

@Controller
@RequestMapping("/cart")
public class CartController {
	@Autowired CartManager cartManager;
@Autowired ProductRepository repo;
@Autowired ProductService sv;

@RequestMapping("/add")
public String add(HttpSession session, @RequestParam("id") Long id, @RequestParam(value = "qty", required = false, defaultValue = "1") int qty) {
	Product product= sv.get(id);
	Cart cart=cartManager.getCart(session);
	cart.addItem(product, qty);
	return "cart";
}
@RequestMapping("/remove")// xoa san pham trong gio hang
public String remove(HttpSession session, @RequestParam("id") Long id) {
	Product product= sv.get(id);
	Cart cart = cartManager.getCart(session);
	cart.removeItem(product);
	return "cart";
}
@RequestMapping("/update")
public String update(HttpSession session, @RequestParam("id") Long id,@RequestParam("qty") int qty) {
	Product product= sv.get(id);
	Cart cart = cartManager.getCart(session);
	cart.updateItem(product, qty);
	
	return "cart";
}
}
