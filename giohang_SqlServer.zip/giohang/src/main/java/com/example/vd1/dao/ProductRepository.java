package com.example.vd1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.vd1.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Long> {
	Product findBySku(String sku);
}
