package com.example.vd1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiohangApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiohangApplication.class, args);
	}

}
