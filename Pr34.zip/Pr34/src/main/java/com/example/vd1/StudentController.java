package com.example.vd1;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student/")
public class StudentController {
	@Autowired
	ServletContext app;
	@RequestMapping("index")
	public String index(HttpServletRequest request,HttpSession session)
	{
		app.setAttribute("name", "Nguyen Van A");
		app.setAttribute("level", 2);
		
		session.setAttribute("name", "TRan Van B");
		session.setAttribute("level", 4);
		
		request.setAttribute("name", "Vu Van C");
		request.setAttribute("level", 6);
		//String path = app.getRealPath("/images/poly.png");
		//String path1 = app.getRealPath("images/poly.png");
		//String path2="images/poly.png";
		session.setAttribute("salary", 1000);
		//request.setAttribute("photo", "images/poly.png");
		request.setAttribute("photo", "files/poly.png");
		
		return "student/index";
		
	}

}
