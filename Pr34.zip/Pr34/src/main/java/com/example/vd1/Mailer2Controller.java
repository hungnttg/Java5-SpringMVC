package com.example.vd1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/mailer2/")
public class Mailer2Controller {
	@Autowired Mailer mailer;
	@RequestMapping("form")
	public String index()
	{
		return "mailer2/form";
	}
	
	@RequestMapping("send")
	public String send(ModelMap model,@RequestParam("from") String from,
			@RequestParam("to") String to,
			@RequestParam("subject") String subject,
			@RequestParam("body") String body)
	{
		try {
			mailer.send(from, to, subject, body);
			model.addAttribute("message", "Gui mail thanh cong");
		} catch (Exception e) {
			model.addAttribute("message", "Gui mail that bai");
		}
		
		return "mailer2/send";
	}

}
