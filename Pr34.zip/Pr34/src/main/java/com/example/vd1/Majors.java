package com.example.vd1;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import hibernate.Student;

@Entity
@Table(name = "Majors")
public class Majors {
	@Id
	private String id;
	private String name;
	public String getId() {
		return id;
	}
	//neu muon su dung Students, thi can quan he OneToMany
	//@OneToMany(mappedBy = "majors",fetch = FetchType.EAGER)
	//private Collection<Student> students;
	
	//public Collection<Student> getStudents() {
	//	return students;
	//}
	//public void setStudents(Collection<Student> students) {
	//	this.students = students;
	//}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Majors(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Majors() {
		super();
	}
	

}
