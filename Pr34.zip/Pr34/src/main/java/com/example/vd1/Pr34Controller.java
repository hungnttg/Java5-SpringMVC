package com.example.vd1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Pr34Controller {

	@RequestMapping(value = {"/list"})
		public String update(@ModelAttribute("student") Student student)
		{
			return "list";
		}
		
		@ModelAttribute("major1")
		public Map<String, String> getMajor1()
		{
			Map<String, String> majors1 = new HashMap<String, String>();
			majors1.put("APP", "Ung dung phan mem");
			majors1.put("WEB", "Thiet ke web");
			return majors1;
		}
		@ModelAttribute("majors")
		public List<Major> getMajors()
		{
			List<Major> majors1 = new ArrayList<Major>();
			majors1.add(new Major("APP", "Ung dung phan mem"));
			majors1.add(new Major("WEB", "Thiet ke web"));
			return majors1;
		}
}
