package com.example.vd1;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.MetaValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@Transactional
@RequestMapping("/majors/")
public class MajorsController {
	@Autowired EntityManagerFactory factory;
	private Session getCurrentSession()
	{
		return factory.unwrap(SessionFactory.class).openSession();
	}
	

	@ModelAttribute("listMajors")
	public List<Majors> listMajors()
	{
		Session session = getCurrentSession();
		String hql = "from Majors";
		Query<Majors> q = session.createQuery(hql,Majors.class);
		List<Majors> list = q.list();
		return list;
	}
	
	@RequestMapping("index")
	public String index(ModelMap model)
	{
		model.addAttribute("majors", new Majors());
		listMajors();
		//model.addAttribute("listMajors",listMajors());
		
		return "majors/index";
	}
	@RequestMapping(value = "index", params = "btnInsert")
	@Transactional
	public String insert(ModelMap model,@ModelAttribute("majors") Majors majors)
	{
		Session session = getCurrentSession();
		Transaction t = session.beginTransaction();
		try {
			session.save(majors);
			t.commit();
			model.addAttribute("message", "Them major thanh cong");
			session.clear();
			session.close();
		} catch (Exception e) {
			model.addAttribute("message", "Them major that");
			// TODO: handle exception
		}
		
		return "redirect:/majors/index";
	}
	
	@RequestMapping(value = "index/edit/{id}", params = "btnUpdate",method = RequestMethod.POST)
	@Transactional
	public String update(ModelMap model,@ModelAttribute("majors") Majors majors)
	{
		Session session = getCurrentSession();
		Transaction t = session.beginTransaction();
		try {
			session.update(majors);
			t.commit();
			model.addAttribute("message", "Update major thanh cong");
			session.clear();
			session.close();
		} catch (Exception e) {
			model.addAttribute("message", "Update major that");
			// TODO: handle exception
		}
		
		return "redirect:/majors/index";
	}
	
	@RequestMapping(value = "index/edit/{id}",method = RequestMethod.GET)
	public String edit(ModelMap model,@PathVariable("id") String id)
	{
		Session session = getCurrentSession();
		Majors majors = (Majors) session.get(Majors.class, id);
		
		model.addAttribute("majors", majors);
		
		
		return "majors/index";
	}

	@RequestMapping(value = "index/delete/{id}",method = RequestMethod.GET)
	public String delete(ModelMap model,@PathVariable("id") String id)
	{
		Session session = getCurrentSession();
		Majors majors = (Majors) session.get(Majors.class, id);
		Transaction t = session.beginTransaction();
		try {
			session.delete(majors);
			t.commit();
			model.addAttribute("message", "Xoa major thanh cong");
			session.close();
		} catch (Exception e) {
			t.rollback();
			model.addAttribute("message", "Xoa major that");
			// TODO: handle exception
		}
		finally {
			session.close();
		}
		
		return "redirect:/majors/index";
	}

}
