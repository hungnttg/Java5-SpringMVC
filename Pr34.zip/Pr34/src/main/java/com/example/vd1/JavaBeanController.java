package com.example.vd1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/javabean/")
@Configuration
@Import(value = {Student.class})
@ImportResource(locations = {"classpath:/com/example/vd1/beancf.xml"})
public class JavaBeanController {
	@Autowired Student student;
	
	@RequestMapping("bean")
	public String bean(ModelMap model)
	{
		return "javabean/bean";
	}
	
	@ModelAttribute("student")
	public Student getStudent()
	{
		return student;
	}

}
