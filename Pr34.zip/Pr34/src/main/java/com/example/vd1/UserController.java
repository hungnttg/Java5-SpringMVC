package com.example.vd1;

import java.util.List;

import org.hibernate.Query;

import javax.persistence.EntityManagerFactory;
import javax.transaction.Transactional;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@Transactional
@RequestMapping("/user/")
public class UserController {
	@Autowired EntityManagerFactory factory;
	private Session getCurrentSession()
	{
		return factory.unwrap(SessionFactory.class).openSession();
	}

	
	
	@RequestMapping("list")
	public String list(ModelMap model)
	{
		Session session = getCurrentSession();
		String hql="from User";	
		Query<User> query = session.createQuery(hql,User.class);
		List<User> list = query.list();
		model.addAttribute("list", list);
		return "user/list";
	}
	@RequestMapping(value = "insert",method = RequestMethod.POST)
	public String insert(ModelMap model,@ModelAttribute("user") User user)
	{
		Session session = getCurrentSession();
		org.hibernate.Transaction t = session.beginTransaction();
		try {
			session.save(user);
			t.commit();
			model.addAttribute("message", "Them moi thanh cong");
		} catch (Exception e) {
			// TODO: handle exception
			t.rollback();
			model.addAttribute("message", "Them that bai");
		}
		
		return "user/insert";
	}
	@RequestMapping(value = "insert",method = RequestMethod.GET)
	public String insert(ModelMap model)
	{
		
			model.addAttribute("user", new User());
		
		
		return "user/insert";
	}
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("detail/{id}")
	public String detail(ModelMap model,@PathVariable("id") String id)
	{
		Session session = getCurrentSession();
		User user = (User)session.get(User.class, id);
		model.addAttribute("user", user);
		return "user/detail";
	}
	@RequestMapping("delete/{id}")
	public String delete(ModelMap model,@PathVariable("id") String id)
	{
		Session session = getCurrentSession();
		User user = (User)session.get(User.class, id);
		session.delete(user);
		return "redirect:/user/list";
	}

}
