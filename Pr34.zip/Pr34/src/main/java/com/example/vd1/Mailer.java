package com.example.vd1;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service("mailer")
public class Mailer {
	@Autowired JavaMailSender mailer;
	
	public void send(String to,String subject,String body) {
		String from = "nguyenvana@gmail.com";
		this.send(from, to, subject, body);
	}
	
	public void send(String from,String to,String subject,String body) {
		this.send(from, to,"","", subject, body,"");
	}
	
	public void send(String from, String to, String subject, String body, String cc, String bcc, String attachment) throws RuntimeException
	{
		try {
			MimeMessage mail = mailer.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mail,true,"utf-8");
			helper.setFrom(from);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setCc(cc);
			helper.setBcc(bcc);
			helper.setText(body,true);
			helper.setReplyTo(from,from);
			if(cc.length()>0)
			{
				cc = cc.trim().replace(";", ",");
				helper.setCc(cc);
			}
			if(bcc.length()>0)
			{
				bcc = bcc.trim().replace(";", ",");
				helper.setBcc(bcc);
			}
			if(attachment.length()>0)
			{
				String[] paths = attachment.split("[,;]+");
				for(String path: paths)
				{
					path = path.replace("/", "\\");
					String fileName = path.substring(1+path.lastIndexOf("\\"));
					helper.addAttachment(fileName, new File(path));
				}
				
			}
			mailer.send(mail);
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}

}
