package hibernate;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.example.vd1.Majors;

@Entity
@Table(name = "Students")
public class Student {
	
	private Integer	id;
	private String fullname;
	private Double mark;
	private Boolean gender;
	private Date birthday;
	//private String majorId;
	@ManyToOne
	@JoinColumn(name = "majorId")
	private Majors major;
	
	public Majors getMajor() {
		return major;
	}
	public void setMajor(Majors major) {
		this.major = major;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public Double getMark() {
		return mark;
	}
	public void setMark(Double mark) {
		this.mark = mark;
	}
	public Boolean getGender() {
		return gender;
	}
	public void setGender(Boolean gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
//	public String getMajorId() {
//		return majorId;
//	}
//	public void setMajorId(String majorId) {
//		this.majorId = majorId;
//	}
	public Student(Integer id, String fullname, Double mark, Boolean gender, Date birthday, Majors major) {
		super();
		this.id = id;
		this.fullname = fullname;
		this.mark = mark;
		this.gender = gender;
		this.birthday = birthday;
		this.major = major;
	}
	public Student() {
		super();
	}
	
	

}
