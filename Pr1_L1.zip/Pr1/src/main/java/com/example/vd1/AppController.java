package com.example.vd1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {
	@RequestMapping("/student/form")
	public String showForm()
	{
		return "student/form";
	}
	@RequestMapping("/student/save")
	public String saveData(HttpServletRequest request)
	{
		//lay ve cac tham so truyen vao
		String name = request.getParameter("name");
		String mark = request.getParameter("mark");
		String major = request.getParameter("major");
		// setAtribute
		request.setAttribute("name", name);
		request.setAttribute("mark", mark);
		request.setAttribute("major", major);
		return "student/success";
	}
}
