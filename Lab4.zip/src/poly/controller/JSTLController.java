package poly.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import poly.bean.Product;
import poly.bean.Student;

@Controller
@RequestMapping("/jstl/")
public class JSTLController {
	@RequestMapping("core-if")
	public String coreIf(ModelMap model) {
		Student student = new Student("Phương", 10.0, "APP");
		model.addAttribute("student", student);
		return "jstl/core-if";
	}
	
	@RequestMapping("core-choose")
	public String coreChoose(ModelMap model) {
		Student student = new Student("Cường", 8.5, "BIZ");
		model.addAttribute("student", student);
		return "jstl/core-choose";
	}
	
	@RequestMapping("core-foreach")
	public String coreForEach(ModelMap model) {
		List<Student> list = new ArrayList<>();
		list.add(new Student("Phương", 10.0, "BIZ"));
		list.add(new Student("Cường", 8.5, "APP"));
		list.add(new Student("Hạnh", 3.5, "MOB"));
		list.add(new Student("Hương", 5.5, "MUL"));
		model.addAttribute("students", list);
		return "jstl/core-foreach";
	}
	
	@RequestMapping("format")
	public String format(ModelMap model) {
		Product product = new Product("iPhone 9", 2579.5, 0.05);
		model.addAttribute("product", product);
		return "jstl/format";
	}
}
