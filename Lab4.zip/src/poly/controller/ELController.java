package poly.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import poly.bean.Student;

@Controller
@RequestMapping("/el/")
public class ELController {
	@RequestMapping("demo1")
	public String demo1(ModelMap model, HttpSession session) {
		session.setAttribute("name", "Tèo");
		model.addAttribute("salary", 2000);
		return "el/demo1";
	}
	
	@RequestMapping("demo2")
	public String demo2(ModelMap model) {
		Student student = new Student("Phương", 10.0, "APP");
		model.addAttribute("student", student);
		return "el/demo2";
	}
	
	@RequestMapping("demo3")
	public String demo3(ModelMap model) {
		List<String> list = new ArrayList<>();
		list.add("Phương");
		list.add("Cường");
		model.addAttribute("items", list);
		return "el/demo3";
	}
	
	@RequestMapping("demo4")
	public String demo4(ModelMap model) {
		Map<String, Object> map = new HashMap<>();
		map.put("name", "Phương");
		map.put("mark", 9.5);
		model.addAttribute("student", map);
		return "el/demo4";
	}
	
	@RequestMapping("login")
	public String login() {
		return "el/login";
	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(ModelMap model, HttpServletResponse response,
			@RequestParam("id") String id, 
			@RequestParam("password") String pw,
			@RequestParam(value="remember", defaultValue="false") Boolean rm) {
		if(id.equals("fpt") && pw.equals("polytechnic")){
			model.addAttribute("message", "Đăng nhập thành công !");
			
			// Ghi nhớ tài khoản 10 ngày bằng cookie
			Cookie ckiId = new Cookie("uid", id);
			Cookie ckiPw = new Cookie("pwd", pw);
			int expiry = 10*24*60*60;
			ckiId.setMaxAge(rm ? expiry : 0);
			ckiPw.setMaxAge(rm ? expiry : 0);
			response.addCookie(ckiId);
			response.addCookie(ckiPw);
		}
		else{
			model.addAttribute("message", "Sai thông tin đăng nhập !");
		}
		return "el/login";
	}
}
