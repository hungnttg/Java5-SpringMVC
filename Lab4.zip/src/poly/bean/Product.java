package poly.bean;

import java.util.Date;

public class Product {
	private String name;
	private Date date;
	private Double price;
	private Double discount;

	public Product() {
		this.date = new Date();
	}
	
	public Product(String name, Double price, Double discount) {
		this.name = name;
		this.price = price;
		this.discount = discount;
		this.date = new Date();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
}
